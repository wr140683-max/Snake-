# Snake Game - Android App

## Build APK (Android Studio)
1. Open this folder in Android Studio
2. Wait for Gradle sync
3. Build → Build Bundle(s) / APK(s) → Build APK(s)
4. APK location: `app/build/outputs/apk/debug/app-debug.apk`

## Requirements
- Android Studio (Hedgehog or newer)
- JDK 17
- Android SDK 34

## Install
Transfer APK to phone and install (enable "Install from unknown sources").
